-- Linux Unity premake module
local platform = {}

function platform.setupTargetAndLibDir(baseTargetDir)
    libdirs(wwiseSDKEnv .. "/Linux_%{cfg.platform}/%{cfg.buildcfg}/lib")
end

function platform.platformSpecificConfiguration()
    
    filter "Profile* or Release*"
        postbuildcommands ("strip " .. "%{cfg.buildtarget.abspath}")

end

return platform